import {
  CityLocation,
  WeatherData,
  TemperatureUnit,
  WindSpeedUnit,
  HourlyForecastItem,
  DailyForecastItem,
} from '../types/weather';

const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes cache
const CACHE_PREFIX = 'aura_weather_cache_';

interface CachedEntry<T> {
  timestamp: number;
  data: T;
}

function getCache<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(CACHE_PREFIX + key);
    if (!raw) return null;
    const parsed: CachedEntry<T> = JSON.parse(raw);
    if (Date.now() - parsed.timestamp > CACHE_TTL_MS) {
      localStorage.removeItem(CACHE_PREFIX + key);
      return null;
    }
    return parsed.data;
  } catch {
    return null;
  }
}

function setCache<T>(key: string, data: T): void {
  try {
    const entry: CachedEntry<T> = {
      timestamp: Date.now(),
      data,
    };
    localStorage.setItem(CACHE_PREFIX + key, JSON.stringify(entry));
  } catch {
    // If quota exceeded, silently clear old cache items
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(CACHE_PREFIX)) {
          localStorage.removeItem(k);
        }
      }
    } catch {
      // ignore
    }
  }
}

export function clearWeatherCache(): void {
  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(CACHE_PREFIX)) {
        keysToRemove.push(k);
      }
    }
    keysToRemove.forEach((k) => localStorage.removeItem(k));
  } catch {
    // ignore
  }
}

/**
 * Fetch city suggestions from Open-Meteo Geocoding API
 */
export async function fetchCitySuggestions(query: string): Promise<CityLocation[]> {
  const trimmed = query.trim();
  if (!trimmed || trimmed.length < 2) {
    return [];
  }

  const cacheKey = `geo_${encodeURIComponent(trimmed.toLowerCase())}`;
  const cached = getCache<CityLocation[]>(cacheKey);
  if (cached) {
    return cached;
  }

  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(trimmed)}&count=6&language=en&format=json`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to search cities (${response.status})`);
  }

  const json = await response.json();
  if (!json.results || !Array.isArray(json.results)) {
    return [];
  }

  const results: CityLocation[] = json.results.map((item: any) => ({
    id: item.id,
    name: item.name,
    latitude: item.latitude,
    longitude: item.longitude,
    country: item.country || '',
    country_code: item.country_code,
    admin1: item.admin1,
    timezone: item.timezone,
  }));

  setCache(cacheKey, results);
  return results;
}

/**
 * Fetch full weather forecast from Open-Meteo API
 */
export async function fetchWeatherForecast(
  city: CityLocation,
  temperatureUnit: TemperatureUnit = 'celsius',
  windSpeedUnit: WindSpeedUnit = 'kmh',
  forceRefresh: boolean = false
): Promise<WeatherData> {
  const roundedLat = city.latitude.toFixed(3);
  const roundedLon = city.longitude.toFixed(3);
  const cacheKey = `forecast_${roundedLat}_${roundedLon}_${temperatureUnit}_${windSpeedUnit}`;

  if (!forceRefresh) {
    const cached = getCache<WeatherData>(cacheKey);
    if (cached) {
      return cached;
    }
  }

  const params = new URLSearchParams({
    latitude: city.latitude.toString(),
    longitude: city.longitude.toString(),
    current:
      'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,pressure_msl',
    daily:
      'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset',
    hourly: 'temperature_2m,weather_code',
    timezone: city.timezone || 'auto',
    forecast_days: '7',
    temperature_unit: temperatureUnit,
    wind_speed_unit: windSpeedUnit,
  });

  const url = `https://api.open-meteo.com/v1/forecast?${params.toString()}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Weather service error (${response.status})`);
  }

  const data = await response.json();

  if (!data.current || !data.daily || !data.hourly) {
    throw new Error('Incomplete weather data returned by Open-Meteo');
  }

  // Format hourly forecast (next 24 hours starting from current time)
  const currentIsoTime = data.current.time;
  const currentHourIndex = data.hourly.time.findIndex((t: string) => t >= currentIsoTime);
  const startIdx = currentHourIndex >= 0 ? currentHourIndex : 0;
  const next24Hours = data.hourly.time.slice(startIdx, startIdx + 24);

  const formattedHourly: HourlyForecastItem[] = next24Hours.map((timeStr: string, index: number) => {
    const actualIdx = startIdx + index;
    const dateObj = new Date(timeStr);
    const hour = dateObj.getHours();
    const formattedTime =
      index === 0
        ? 'Now'
        : dateObj.toLocaleTimeString([], { hour: 'numeric', hour12: true });

    return {
      time: timeStr,
      formattedTime,
      temperature: Math.round(data.hourly.temperature_2m[actualIdx]),
      weatherCode: data.hourly.weather_code[actualIdx],
      isDaytime: hour >= 6 && hour < 19,
    };
  });

  // Format 7-day daily forecast
  const formattedDaily: DailyForecastItem[] = data.daily.time.map(
    (dateStr: string, idx: number) => {
      const dateObj = new Date(dateStr + 'T12:00:00');
      const isToday = idx === 0;
      const dayName = isToday
        ? 'Today'
        : dateObj.toLocaleDateString([], { weekday: 'short' });
      const formattedDate = dateObj.toLocaleDateString([], {
        month: 'short',
        day: 'numeric',
      });

      return {
        date: dateStr,
        dayName,
        formattedDate,
        weatherCode: data.daily.weather_code[idx],
        temperatureMax: Math.round(data.daily.temperature_2m_max[idx]),
        temperatureMin: Math.round(data.daily.temperature_2m_min[idx]),
        precipitationProbability:
          data.daily.precipitation_probability_max?.[idx] ?? 0,
        sunrise: data.daily.sunrise?.[idx]
          ? new Date(data.daily.sunrise[idx]).toLocaleTimeString([], {
              hour: 'numeric',
              minute: '2-digit',
              hour12: true,
            })
          : '--:--',
        sunset: data.daily.sunset?.[idx]
          ? new Date(data.daily.sunset[idx]).toLocaleTimeString([], {
              hour: 'numeric',
              minute: '2-digit',
              hour12: true,
            })
          : '--:--',
      };
    }
  );

  const result: WeatherData = {
    city,
    current: {
      temperature: Math.round(data.current.temperature_2m),
      apparentTemperature: Math.round(data.current.apparent_temperature),
      humidity: Math.round(data.current.relative_humidity_2m),
      weatherCode: data.current.weather_code,
      windSpeed: Math.round(data.current.wind_speed_10m * 10) / 10,
      pressure: Math.round(data.current.pressure_msl),
      time: data.current.time,
    },
    hourly: formattedHourly,
    daily: formattedDaily,
    temperatureUnit,
    windSpeedUnit,
    fetchedAt: Date.now(),
  };

  setCache(cacheKey, result);
  return result;
}

/**
 * Reverse geocode by latitude & longitude using Open-Meteo or fallback naming
 */
export async function fetchLocationFromCoordinates(
  latitude: number,
  longitude: number
): Promise<CityLocation> {
  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=a&count=1&language=en`;
    // Open-Meteo doesn't have an official free reverse endpoint, so we can use bigdatacloud or nominatim or a resilient fallback
    const revUrl = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`;
    const resp = await fetch(revUrl);
    if (resp.ok) {
      const data = await resp.json();
      return {
        id: Math.round(latitude * 1000 + longitude * 1000),
        name: data.city || data.locality || data.principalSubdivision || 'Current Location',
        latitude,
        longitude,
        country: data.countryName || '',
        country_code: data.countryCode,
        admin1: data.principalSubdivision,
      };
    }
  } catch {
    // fallback
  }

  return {
    id: Math.round(latitude * 1000 + longitude * 1000),
    name: 'Current Location',
    latitude,
    longitude,
    country: '',
  };
}
