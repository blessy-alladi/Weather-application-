import React from 'react';
import {
  Sun,
  Moon,
  CloudSun,
  CloudMoon,
  Cloud,
  CloudRain,
  CloudDrizzle,
  CloudSnow,
  CloudLightning,
  CloudFog,
  CloudHail,
} from 'lucide-react';
import { WeatherConditionInfo } from '../types/weather';

export function getWeatherConditionInfo(code: number, isDay: boolean = true): WeatherConditionInfo {
  // WMO Weather interpretation codes (WW)
  switch (code) {
    case 0:
      return {
        code,
        label: isDay ? 'Clear Sky' : 'Clear Night',
        iconName: isDay ? 'Sun' : 'Moon',
        category: 'clear',
        gradientLight: 'from-amber-400/25 via-sky-300/25 to-blue-500/20',
        gradientDark: 'from-sky-950 via-indigo-950 to-slate-950',
        cardLight: 'bg-white/80 border-amber-200/60 shadow-amber-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-sky-950/20',
      };
    case 1:
      return {
        code,
        label: isDay ? 'Mainly Clear' : 'Mostly Clear',
        iconName: isDay ? 'Sun' : 'Moon',
        category: 'clear',
        gradientLight: 'from-amber-300/20 via-sky-200/25 to-blue-400/20',
        gradientDark: 'from-slate-950 via-slate-900 to-indigo-950',
        cardLight: 'bg-white/80 border-sky-200/60 shadow-sky-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 2:
      return {
        code,
        label: 'Partly Cloudy',
        iconName: isDay ? 'CloudSun' : 'CloudMoon',
        category: 'cloudy',
        gradientLight: 'from-sky-200/30 via-slate-200/30 to-blue-200/25',
        gradientDark: 'from-slate-950 via-slate-900 to-cyan-950',
        cardLight: 'bg-white/80 border-slate-200/70 shadow-slate-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 3:
      return {
        code,
        label: 'Overcast',
        iconName: 'Cloud',
        category: 'cloudy',
        gradientLight: 'from-slate-300/30 via-zinc-200/35 to-slate-200/30',
        gradientDark: 'from-zinc-950 via-slate-950 to-neutral-950',
        cardLight: 'bg-white/85 border-slate-200/80 shadow-slate-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 45:
    case 48:
      return {
        code,
        label: code === 45 ? 'Foggy' : 'Depositing Rime Fog',
        iconName: 'CloudFog',
        category: 'fog',
        gradientLight: 'from-slate-300/25 via-emerald-100/20 to-teal-100/20',
        gradientDark: 'from-slate-950 via-zinc-900 to-slate-900',
        cardLight: 'bg-white/85 border-slate-200/70 shadow-slate-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 51:
    case 53:
    case 55:
      return {
        code,
        label: code === 51 ? 'Light Drizzle' : code === 53 ? 'Moderate Drizzle' : 'Dense Drizzle',
        iconName: 'CloudDrizzle',
        category: 'rain',
        gradientLight: 'from-blue-200/30 via-teal-100/25 to-slate-200/30',
        gradientDark: 'from-slate-950 via-cyan-950 to-slate-900',
        cardLight: 'bg-white/85 border-blue-200/60 shadow-blue-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-cyan-950/20',
      };
    case 56:
    case 57:
      return {
        code,
        label: 'Freezing Drizzle',
        iconName: 'CloudHail',
        category: 'snow',
        gradientLight: 'from-cyan-200/30 via-sky-100/30 to-blue-200/25',
        gradientDark: 'from-slate-950 via-sky-950 to-slate-900',
        cardLight: 'bg-white/85 border-cyan-200/70 shadow-cyan-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-sky-950/20',
      };
    case 61:
    case 63:
    case 65:
      return {
        code,
        label: code === 61 ? 'Slight Rain' : code === 63 ? 'Moderate Rain' : 'Heavy Rain',
        iconName: 'CloudRain',
        category: 'rain',
        gradientLight: 'from-sky-300/35 via-blue-200/30 to-slate-300/30',
        gradientDark: 'from-slate-950 via-blue-950 to-slate-900',
        cardLight: 'bg-white/85 border-sky-200/70 shadow-sky-600/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-blue-950/25',
      };
    case 66:
    case 67:
      return {
        code,
        label: 'Freezing Rain',
        iconName: 'CloudHail',
        category: 'rain',
        gradientLight: 'from-cyan-300/25 via-blue-200/25 to-slate-200/30',
        gradientDark: 'from-slate-950 via-cyan-950 to-slate-900',
        cardLight: 'bg-white/85 border-cyan-200/60 shadow-cyan-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-cyan-950/20',
      };
    case 71:
    case 73:
    case 75:
    case 77:
      return {
        code,
        label: code === 71 ? 'Light Snow' : code === 73 ? 'Moderate Snow' : code === 75 ? 'Heavy Snow' : 'Snow Grains',
        iconName: 'CloudSnow',
        category: 'snow',
        gradientLight: 'from-sky-200/40 via-indigo-100/30 to-slate-200/30',
        gradientDark: 'from-slate-950 via-slate-900 to-sky-950',
        cardLight: 'bg-white/85 border-sky-200/70 shadow-sky-400/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 80:
    case 81:
    case 82:
      return {
        code,
        label: code === 80 ? 'Light Showers' : code === 81 ? 'Moderate Showers' : 'Violent Showers',
        iconName: 'CloudRain',
        category: 'rain',
        gradientLight: 'from-blue-300/35 via-sky-200/30 to-indigo-200/25',
        gradientDark: 'from-slate-950 via-blue-950 to-indigo-950',
        cardLight: 'bg-white/85 border-blue-200/70 shadow-blue-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-blue-950/25',
      };
    case 85:
    case 86:
      return {
        code,
        label: 'Snow Showers',
        iconName: 'CloudSnow',
        category: 'snow',
        gradientLight: 'from-sky-200/35 via-cyan-100/35 to-blue-200/25',
        gradientDark: 'from-slate-950 via-slate-900 to-cyan-950',
        cardLight: 'bg-white/85 border-cyan-200/70 shadow-cyan-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
    case 95:
      return {
        code,
        label: 'Thunderstorm',
        iconName: 'CloudLightning',
        category: 'thunderstorm',
        gradientLight: 'from-indigo-300/35 via-purple-200/30 to-slate-300/30',
        gradientDark: 'from-slate-950 via-purple-950 to-slate-950',
        cardLight: 'bg-white/85 border-purple-200/70 shadow-purple-500/5',
        cardDark: 'bg-slate-900/80 border-purple-950/60 shadow-purple-950/30',
      };
    case 96:
    case 99:
      return {
        code,
        label: 'Severe Thunderstorm & Hail',
        iconName: 'CloudLightning',
        category: 'thunderstorm',
        gradientLight: 'from-violet-300/40 via-slate-300/35 to-purple-300/30',
        gradientDark: 'from-slate-950 via-indigo-950 to-slate-900',
        cardLight: 'bg-white/85 border-violet-200/70 shadow-violet-500/5',
        cardDark: 'bg-slate-900/80 border-violet-950/60 shadow-violet-950/30',
      };
    default:
      return {
        code,
        label: 'Variable Conditions',
        iconName: 'Cloud',
        category: 'cloudy',
        gradientLight: 'from-sky-200/25 via-slate-200/25 to-blue-200/20',
        gradientDark: 'from-slate-950 via-slate-900 to-slate-950',
        cardLight: 'bg-white/85 border-slate-200/70 shadow-slate-500/5',
        cardDark: 'bg-slate-900/80 border-slate-800 shadow-slate-950/20',
      };
  }
}

interface WeatherIconProps {
  code: number;
  isDay?: boolean;
  className?: string;
}

export function WeatherIcon({ code, isDay = true, className = 'w-6 h-6' }: WeatherIconProps) {
  const info = getWeatherConditionInfo(code, isDay);

  switch (info.iconName) {
    case 'Sun':
      return <Sun className={`text-amber-500 ${className}`} aria-hidden="true" />;
    case 'Moon':
      return <Moon className={`text-sky-300 ${className}`} aria-hidden="true" />;
    case 'CloudSun':
      return <CloudSun className={`text-amber-500 dark:text-amber-400 ${className}`} aria-hidden="true" />;
    case 'CloudMoon':
      return <CloudMoon className={`text-sky-300 ${className}`} aria-hidden="true" />;
    case 'Cloud':
      return <Cloud className={`text-slate-400 dark:text-slate-300 ${className}`} aria-hidden="true" />;
    case 'CloudRain':
      return <CloudRain className={`text-sky-500 dark:text-sky-400 ${className}`} aria-hidden="true" />;
    case 'CloudDrizzle':
      return <CloudDrizzle className={`text-teal-500 dark:text-teal-400 ${className}`} aria-hidden="true" />;
    case 'CloudSnow':
      return <CloudSnow className={`text-sky-300 dark:text-sky-200 ${className}`} aria-hidden="true" />;
    case 'CloudLightning':
      return <CloudLightning className={`text-purple-500 dark:text-purple-400 ${className}`} aria-hidden="true" />;
    case 'CloudFog':
      return <CloudFog className={`text-slate-400 dark:text-slate-400 ${className}`} aria-hidden="true" />;
    case 'CloudHail':
      return <CloudHail className={`text-cyan-400 dark:text-cyan-300 ${className}`} aria-hidden="true" />;
    default:
      return <Sun className={`text-amber-500 ${className}`} aria-hidden="true" />;
  }
}
