export type TemperatureUnit = 'celsius' | 'fahrenheit';
export type WindSpeedUnit = 'kmh' | 'mph';
export type ThemeMode = 'light' | 'dark' | 'system';

export interface CityLocation {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  country_code?: string;
  admin1?: string;
  timezone?: string;
}

export interface CurrentWeather {
  temperature: number;
  apparentTemperature: number;
  humidity: number;
  weatherCode: number;
  windSpeed: number;
  pressure: number;
  time: string;
}

export interface HourlyForecastItem {
  time: string;
  formattedTime: string;
  temperature: number;
  weatherCode: number;
  isDaytime?: boolean;
}

export interface DailyForecastItem {
  date: string;
  dayName: string;
  formattedDate: string;
  weatherCode: number;
  temperatureMax: number;
  temperatureMin: number;
  precipitationProbability: number;
  sunrise: string;
  sunset: string;
}

export interface WeatherData {
  city: CityLocation;
  current: CurrentWeather;
  hourly: HourlyForecastItem[];
  daily: DailyForecastItem[];
  temperatureUnit: TemperatureUnit;
  windSpeedUnit: WindSpeedUnit;
  fetchedAt: number;
}

export interface WeatherConditionInfo {
  code: number;
  label: string;
  iconName: string;
  category: 'clear' | 'cloudy' | 'rain' | 'snow' | 'thunderstorm' | 'fog';
  gradientLight: string;
  gradientDark: string;
  cardLight: string;
  cardDark: string;
}

export interface SavedCityItem {
  city: CityLocation;
  currentTemp?: number;
  weatherCode?: number;
  tempMax?: number;
  tempMin?: number;
  updatedAt?: number;
}

export interface AppSettings {
  temperatureUnit: TemperatureUnit;
  windSpeedUnit: WindSpeedUnit;
  theme: ThemeMode;
}
