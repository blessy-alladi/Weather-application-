/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { WeatherProvider, useWeather } from './context/WeatherContext';
import { Header } from './components/common/Header';
import { Navigation } from './components/common/Navigation';
import { HomePage } from './pages/HomePage';
import { DetailPage } from './pages/DetailPage';
import { SavedCitiesPage } from './pages/SavedCitiesPage';
import { SettingsPage } from './pages/SettingsPage';
import { getWeatherConditionInfo } from './utils/weatherCodes';

function AppContent() {
  const { activeScreen, weather } = useWeather();

  const condition = weather
    ? getWeatherConditionInfo(weather.current.weatherCode)
    : null;

  const bgGradient = condition
    ? `bg-gradient-to-br ${condition.gradientLight} dark:${condition.gradientDark}`
    : 'bg-gradient-to-br from-sky-100/40 via-slate-50 to-indigo-100/40 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950';

  return (
    <div
      className={`min-h-screen text-slate-800 dark:text-slate-100 flex flex-col transition-colors duration-700 ${bgGradient}`}
    >
      {/* Top Header */}
      <Header />

      {/* Main Body Split: Desktop Sidebar + Content Area */}
      <div className="flex-1 flex w-full max-w-7xl mx-auto">
        <Navigation />

        <main className="flex-1 px-4 sm:px-6 lg:px-8 pt-6 pb-24 md:pb-12 min-w-0">
          {activeScreen === 'home' && <HomePage />}
          {activeScreen === 'detail' && <DetailPage />}
          {activeScreen === 'saved' && <SavedCitiesPage />}
          {activeScreen === 'settings' && <SettingsPage />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <WeatherProvider>
      <AppContent />
    </WeatherProvider>
  );
}
