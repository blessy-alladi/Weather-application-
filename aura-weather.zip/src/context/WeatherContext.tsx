import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';
import {
  CityLocation,
  WeatherData,
  SavedCityItem,
  AppSettings,
  TemperatureUnit,
  WindSpeedUnit,
  ThemeMode,
} from '../types/weather';
import {
  fetchWeatherForecast,
  fetchLocationFromCoordinates,
} from '../services/weatherApi';

const DEFAULT_CITY: CityLocation = {
  id: 1261481,
  name: 'New Delhi',
  latitude: 28.6139,
  longitude: 77.209,
  country: 'India',
  country_code: 'IN',
  admin1: 'Delhi',
  timezone: 'Asia/Kolkata',
};

const DEFAULT_SETTINGS: AppSettings = {
  temperatureUnit: 'celsius',
  windSpeedUnit: 'kmh',
  theme: 'system',
};

const STORAGE_KEYS = {
  LAST_CITY: 'aura_weather_last_city',
  SAVED_CITIES: 'aura_weather_saved_cities',
  SETTINGS: 'aura_weather_settings',
};

export type ScreenType = 'home' | 'detail' | 'saved' | 'settings';

interface WeatherContextType {
  activeCity: CityLocation;
  setActiveCity: (city: CityLocation) => void;
  weather: WeatherData | null;
  isLoading: boolean;
  error: string | null;
  refreshWeather: (force?: boolean) => Promise<void>;
  savedCities: SavedCityItem[];
  isCitySaved: (cityId: number) => boolean;
  toggleSaveCity: (city?: CityLocation) => void;
  removeSavedCity: (cityId: number) => void;
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  activeScreen: ScreenType;
  setActiveScreen: (screen: ScreenType) => void;
  locateUser: () => Promise<void>;
  isLocating: boolean;
}

const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

export function WeatherProvider({ children }: { children: ReactNode }) {
  // 1. Settings state
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (stored) return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  // 2. Active city state (remember last searched city or default)
  const [activeCity, setActiveCityState] = useState<CityLocation>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LAST_CITY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return DEFAULT_CITY;
  });

  // 3. Saved cities state
  const [savedCities, setSavedCities] = useState<SavedCityItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SAVED_CITIES);
      if (stored) return JSON.parse(stored);
    } catch {}
    return [];
  });

  // 4. Weather data & UI state
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeScreen, setActiveScreen] = useState<ScreenType>('home');
  const [isLocating, setIsLocating] = useState<boolean>(false);

  // Apply Theme to document.documentElement
  useEffect(() => {
    const root = document.documentElement;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = () => {
      const isDark =
        settings.theme === 'dark' ||
        (settings.theme === 'system' && mediaQuery.matches);

      if (isDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    applyTheme();

    if (settings.theme === 'system') {
      mediaQuery.addEventListener('change', applyTheme);
      return () => mediaQuery.removeEventListener('change', applyTheme);
    }
  }, [settings.theme]);

  // Load weather for active city
  const loadWeatherData = useCallback(
    async (city: CityLocation, force: boolean = false) => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await fetchWeatherForecast(
          city,
          settings.temperatureUnit,
          settings.windSpeedUnit,
          force
        );
        setWeather(data);

        // Update the saved city snapshot if it exists in saved list
        setSavedCities((prev) =>
          prev.map((item) =>
            item.city.id === city.id
              ? {
                  ...item,
                  currentTemp: data.current.temperature,
                  weatherCode: data.current.weatherCode,
                  tempMax: data.daily[0]?.temperatureMax,
                  tempMin: data.daily[0]?.temperatureMin,
                  updatedAt: Date.now(),
                }
              : item
          )
        );
      } catch (err: any) {
        console.error('Failed to load weather:', err);
        setError(err.message || 'Unable to fetch weather forecast. Please check your network.');
      } finally {
        setIsLoading(false);
      }
    },
    [settings.temperatureUnit, settings.windSpeedUnit]
  );

  // Trigger weather fetch when activeCity or unit settings change
  useEffect(() => {
    loadWeatherData(activeCity, false);
  }, [activeCity, loadWeatherData]);

  // Save activeCity to localStorage
  const setActiveCity = useCallback((city: CityLocation) => {
    setActiveCityState(city);
    try {
      localStorage.setItem(STORAGE_KEYS.LAST_CITY, JSON.stringify(city));
    } catch {}
  }, []);

  // Persist settings
  const updateSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  // Persist saved cities
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SAVED_CITIES, JSON.stringify(savedCities));
    } catch {}
  }, [savedCities]);

  // Check if city is saved
  const isCitySaved = useCallback(
    (cityId: number) => {
      return savedCities.some((item) => item.city.id === cityId);
    },
    [savedCities]
  );

  // Toggle save city
  const toggleSaveCity = useCallback(
    (targetCity?: CityLocation) => {
      const cityToToggle = targetCity || activeCity;
      setSavedCities((prev) => {
        const exists = prev.some((item) => item.city.id === cityToToggle.id);
        if (exists) {
          return prev.filter((item) => item.city.id !== cityToToggle.id);
        } else {
          const newEntry: SavedCityItem = {
            city: cityToToggle,
            currentTemp: weather?.current.temperature,
            weatherCode: weather?.current.weatherCode,
            tempMax: weather?.daily[0]?.temperatureMax,
            tempMin: weather?.daily[0]?.temperatureMin,
            updatedAt: Date.now(),
          };
          return [newEntry, ...prev];
        }
      });
    },
    [activeCity, weather]
  );

  // Remove saved city
  const removeSavedCity = useCallback((cityId: number) => {
    setSavedCities((prev) => prev.filter((item) => item.city.id !== cityId));
  }, []);

  // Refresh active weather manually
  const refreshWeather = useCallback(
    async (force: boolean = true) => {
      await loadWeatherData(activeCity, force);
    },
    [activeCity, loadWeatherData]
  );

  // Geolocation lookup
  const locateUser = useCallback(async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          const loc = await fetchLocationFromCoordinates(lat, lon);
          setActiveCity(loc);
        } catch (err: any) {
          setError('Could not identify your current city location.');
        } finally {
          setIsLocating(false);
        }
      },
      (err) => {
        console.warn('Geolocation error:', err);
        setIsLocating(false);
        if (err.code === err.PERMISSION_DENIED) {
          setError('Location permission was denied. You can search for your city above.');
        } else {
          setError('Unable to retrieve your location coordinates.');
        }
      },
      { timeout: 10000, enableHighAccuracy: false }
    );
  }, [setActiveCity]);

  return (
    <WeatherContext.Provider
      value={{
        activeCity,
        setActiveCity,
        weather,
        isLoading,
        error,
        refreshWeather,
        savedCities,
        isCitySaved,
        toggleSaveCity,
        removeSavedCity,
        settings,
        updateSettings,
        activeScreen,
        setActiveScreen,
        locateUser,
        isLocating,
      }}
    >
      {children}
    </WeatherContext.Provider>
  );
}

export function useWeather() {
  const context = useContext(WeatherContext);
  if (!context) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
}
