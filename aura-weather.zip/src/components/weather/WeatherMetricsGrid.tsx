import React from 'react';
import {
  Sunrise,
  Sunset,
  Droplets,
  Wind,
  Gauge,
  Thermometer,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';

export function WeatherMetricsGrid() {
  const { weather, settings } = useWeather();

  if (!weather) return null;

  const { current, daily } = weather;
  const today = daily[0];
  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°C' : '°F';
  const windUnit = settings.windSpeedUnit === 'kmh' ? 'km/h' : 'mph';

  // Calculate humidity comfort level
  const getHumidityFeedback = (hum: number) => {
    if (hum < 30) return 'Dry environment';
    if (hum <= 60) return 'Ideal comfort level';
    if (hum <= 75) return 'Moderate humidity';
    return 'High humidity, muggy';
  };

  // Calculate pressure tendency
  const getPressureFeedback = (hpa: number) => {
    if (hpa > 1018) return 'High pressure · Settled skies';
    if (hpa >= 1008) return 'Normal standard pressure';
    return 'Low pressure · Chance of storm/rain';
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* 1. Sunrise & Sunset */}
      <div className="rounded-3xl p-5 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          <span>Sun & Daylight</span>
          <Sunrise className="w-4 h-4 text-amber-500" />
        </div>
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <Sunrise className="w-4 h-4 text-amber-500" /> Sunrise
            </span>
            <span className="font-bold font-mono text-slate-900 dark:text-white">
              {today?.sunrise || '--:--'}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <Sunset className="w-4 h-4 text-orange-500" /> Sunset
            </span>
            <span className="font-bold font-mono text-slate-900 dark:text-white">
              {today?.sunset || '--:--'}
            </span>
          </div>
        </div>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
          Solar daylight cycle calculated for local latitude
        </p>
      </div>

      {/* 2. Feels Like & Thermal Comfort */}
      <div className="rounded-3xl p-5 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          <span>Apparent Thermal</span>
          <Thermometer className="w-4 h-4 text-rose-500" />
        </div>
        <div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
            {current.apparentTemperature}{tempSymbol}
          </p>
          <p className="text-xs font-medium text-slate-600 dark:text-slate-300 mt-1">
            {current.apparentTemperature === current.temperature
              ? 'Matches actual temperature'
              : current.apparentTemperature > current.temperature
              ? 'Warmer than ambient air'
              : 'Wind chill makes it feel cooler'}
          </p>
        </div>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
          Actual reading: {current.temperature}{tempSymbol}
        </p>
      </div>

      {/* 3. Humidity & Moisture */}
      <div className="rounded-3xl p-5 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          <span>Relative Humidity</span>
          <Droplets className="w-4 h-4 text-sky-500" />
        </div>
        <div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
            {current.humidity}%
          </p>
          <p className="text-xs font-medium text-slate-600 dark:text-slate-300 mt-1">
            {getHumidityFeedback(current.humidity)}
          </p>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className="bg-sky-500 h-full rounded-full transition-all"
            style={{ width: `${current.humidity}%` }}
          />
        </div>
      </div>

      {/* 4. Atmospheric Pressure */}
      <div className="rounded-3xl p-5 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          <span>Barometric Pressure</span>
          <Gauge className="w-4 h-4 text-indigo-500" />
        </div>
        <div>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
            {current.pressure} <span className="text-sm font-normal text-slate-500">hPa</span>
          </p>
          <p className="text-xs font-medium text-slate-600 dark:text-slate-300 mt-1">
            {getPressureFeedback(current.pressure)}
          </p>
        </div>
        <p className="text-[11px] text-slate-400 dark:text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
          Sea-level adjusted MSL
        </p>
      </div>
    </div>
  );
}
