import React, { useState } from 'react';
import { TrendingUp } from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';
import { getWeatherConditionInfo, WeatherIcon } from '../../utils/weatherCodes';

export function TemperatureChart() {
  const { weather, settings } = useWeather();
  const [activeIdx, setActiveIdx] = useState<number | null>(null);

  if (!weather || !weather.daily || weather.daily.length === 0) return null;

  const data = weather.daily;
  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°C' : '°F';

  // Extract max and min temperatures
  const maxTemps = data.map((d) => d.temperatureMax);
  const minTemps = data.map((d) => d.temperatureMin);
  const minVal = Math.min(...minTemps) - 2;
  const maxVal = Math.max(...maxTemps) + 2;
  const range = maxVal - minVal || 1;

  // Chart dimensions in viewBox coordinates
  const width = 600;
  const height = 180;
  const paddingX = 40;
  const paddingTop = 25;
  const paddingBottom = 35;
  const chartHeight = height - paddingTop - paddingBottom;
  const stepX = (width - paddingX * 2) / (data.length - 1);

  // Map temperature to Y coordinate
  const getY = (val: number) => {
    const norm = (val - minVal) / range;
    return height - paddingBottom - norm * chartHeight;
  };

  // Generate smooth cubic bezier SVG path
  const makeSmoothPath = (points: { x: number; y: number }[]) => {
    if (points.length < 2) return '';
    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = i > 0 ? points[i - 1] : points[0];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = i != points.length - 2 ? points[i + 2] : p2;

      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
    }
    return d;
  };

  const highPoints = data.map((d, i) => ({
    x: paddingX + i * stepX,
    y: getY(d.temperatureMax),
  }));

  const lowPoints = data.map((d, i) => ({
    x: paddingX + i * stepX,
    y: getY(d.temperatureMin),
  }));

  const highPath = makeSmoothPath(highPoints);
  const lowPath = makeSmoothPath(lowPoints);

  // Closed area polygon for high area
  const areaPath = `${highPath} L ${highPoints[highPoints.length - 1].x} ${height - paddingBottom} L ${highPoints[0].x} ${height - paddingBottom} Z`;

  const hoveredDay = activeIdx !== null ? data[activeIdx] : null;

  return (
    <div className="rounded-3xl p-5 sm:p-6 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-sky-500" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Temperature Trend
          </h2>
        </div>
        <div className="flex items-center gap-4 text-xs font-medium">
          <div className="flex items-center gap-1.5 text-rose-500">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
            <span>High</span>
          </div>
          <div className="flex items-center gap-1.5 text-sky-500">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-500 inline-block" />
            <span>Low</span>
          </div>
        </div>
      </div>

      {/* Interactive Tooltip Card if hovering */}
      <div className="min-h-[38px] flex items-center justify-between px-3 py-1.5 rounded-xl bg-slate-100/70 dark:bg-slate-800/60 border border-slate-200/50 dark:border-slate-700/50 text-xs">
        {hoveredDay ? (
          <>
            <div className="flex items-center gap-2">
              <WeatherIcon code={hoveredDay.weatherCode} className="w-4 h-4" />
              <span className="font-bold text-slate-900 dark:text-white">
                {hoveredDay.dayName} ({hoveredDay.formattedDate})
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                · {getWeatherConditionInfo(hoveredDay.weatherCode).label}
              </span>
            </div>
            <div className="font-mono tabular-nums space-x-2">
              <span className="text-rose-500 font-bold">
                Max: {hoveredDay.temperatureMax}{tempSymbol}
              </span>
              <span className="text-sky-500 font-bold">
                Min: {hoveredDay.temperatureMin}{tempSymbol}
              </span>
            </div>
          </>
        ) : (
          <span className="text-slate-400 dark:text-slate-500">
            Hover or tap points on the graph to inspect detailed temperatures
          </span>
        )}
      </div>

      {/* Responsive SVG Chart */}
      <div className="relative w-full aspect-[600/180]">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full overflow-visible select-none"
        >
          <defs>
            <linearGradient id="tempAreaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.25" />
              <stop offset="60%" stopColor="#0ea5e9" stopOpacity="0.10" />
              <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1={paddingX}
            y1={height - paddingBottom}
            x2={width - paddingX}
            y2={height - paddingBottom}
            stroke="currentColor"
            className="text-slate-200 dark:text-slate-800 stroke-[1]"
          />

          {/* Gradient area */}
          <path d={areaPath} fill="url(#tempAreaGradient)" />

          {/* Low temperature curve */}
          <path
            d={lowPath}
            fill="none"
            stroke="#0ea5e9"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* High temperature curve */}
          <path
            d={highPath}
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Vertical inspection guideline & data points */}
          {data.map((day, i) => {
            const hPt = highPoints[i];
            const lPt = lowPoints[i];
            const isHovered = activeIdx === i;

            return (
              <g
                key={day.date}
                className="cursor-pointer"
                onMouseEnter={() => setActiveIdx(i)}
                onMouseLeave={() => setActiveIdx(null)}
                onClick={() => setActiveIdx(i)}
              >
                {/* Invisible wide tap hitbox */}
                <rect
                  x={hPt.x - stepX / 2}
                  y={0}
                  width={stepX}
                  height={height}
                  fill="transparent"
                />

                {isHovered && (
                  <line
                    x1={hPt.x}
                    y1={paddingTop - 10}
                    x2={hPt.x}
                    y2={height - paddingBottom}
                    stroke="#38bdf8"
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                  />
                )}

                {/* Day label */}
                <text
                  x={hPt.x}
                  y={height - paddingBottom + 18}
                  textAnchor="middle"
                  className={`text-[11px] font-semibold ${
                    isHovered
                      ? 'fill-sky-500 font-bold'
                      : 'fill-slate-500 dark:fill-slate-400'
                  }`}
                >
                  {day.dayName}
                </text>

                {/* High point */}
                <circle
                  cx={hPt.x}
                  cy={hPt.y}
                  r={isHovered ? 5.5 : 3.5}
                  fill="#f43f5e"
                  stroke="#ffffff"
                  strokeWidth={isHovered ? 2.5 : 1.5}
                  className="transition-all"
                />

                {/* High value label */}
                <text
                  x={hPt.x}
                  y={hPt.y - 8}
                  textAnchor="middle"
                  className="text-[10px] font-bold font-mono fill-rose-500 tabular-nums"
                >
                  {day.temperatureMax}°
                </text>

                {/* Low point */}
                <circle
                  cx={lPt.x}
                  cy={lPt.y}
                  r={isHovered ? 5.5 : 3.5}
                  fill="#0ea5e9"
                  stroke="#ffffff"
                  strokeWidth={isHovered ? 2.5 : 1.5}
                  className="transition-all"
                />

                {/* Low value label */}
                <text
                  x={lPt.x}
                  y={lPt.y + 16}
                  textAnchor="middle"
                  className="text-[10px] font-bold font-mono fill-sky-500 tabular-nums"
                >
                  {day.temperatureMin}°
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
