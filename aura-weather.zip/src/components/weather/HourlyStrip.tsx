import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';
import { WeatherIcon } from '../../utils/weatherCodes';

export function HourlyStrip() {
  const { weather, settings } = useWeather();
  const scrollRef = useRef<HTMLDivElement>(null);

  if (!weather || !weather.hourly || weather.hourly.length === 0) return null;

  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°' : '°';

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const offset = direction === 'left' ? -260 : 260;
      scrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <div className="rounded-3xl p-5 sm:p-6 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-sky-500" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Next 24 Hours
          </h2>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => scroll('left')}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Scroll hourly forecast left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Scroll hourly forecast right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        tabIndex={0}
        aria-label="24-hour weather timeline"
        className="flex gap-3 overflow-x-auto no-scrollbar py-2 focus:outline-none focus:ring-1 focus:ring-sky-500 rounded-2xl"
      >
        {weather.hourly.map((item, idx) => {
          const isNow = idx === 0;
          return (
            <div
              key={`${item.time}-${idx}`}
              className={`flex flex-col items-center justify-between min-w-[76px] py-3.5 px-2.5 rounded-2xl transition-transform hover:-translate-y-0.5 border ${
                isNow
                  ? 'bg-sky-500/10 dark:bg-sky-500/15 border-sky-500/30 text-sky-950 dark:text-sky-100'
                  : 'bg-white/50 dark:bg-slate-800/50 border-slate-200/60 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span className={`text-xs font-semibold ${isNow ? 'text-sky-600 dark:text-sky-400' : 'text-slate-500 dark:text-slate-400'}`}>
                {item.formattedTime}
              </span>

              <div className="my-2.5">
                <WeatherIcon
                  code={item.weatherCode}
                  isDay={item.isDaytime}
                  className="w-7 h-7"
                />
              </div>

              <span className="text-base font-bold tabular-nums">
                {item.temperature}{tempSymbol}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
