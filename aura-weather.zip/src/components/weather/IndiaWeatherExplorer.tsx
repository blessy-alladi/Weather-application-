import React, { useState } from 'react';
import { MapPin, Sparkles, Heart, ArrowUpRight } from 'lucide-react';
import { INDIAN_REGIONS } from '../../data/indianCities';
import { useWeather } from '../../context/WeatherContext';
import { CityLocation } from '../../types/weather';

export function IndiaWeatherExplorer() {
  const {
    activeCity,
    setActiveCity,
    setActiveScreen,
    isCitySaved,
    toggleSaveCity,
  } = useWeather();
  const [selectedCategory, setSelectedCategory] = useState<string>('Metros');

  const activeRegion =
    INDIAN_REGIONS.find((r) => r.category === selectedCategory) ||
    INDIAN_REGIONS[0];

  const handleSelectCity = (city: CityLocation) => {
    setActiveCity(city);
    // Smooth scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenDetail = (city: CityLocation, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveCity(city);
    setActiveScreen('detail');
  };

  return (
    <div className="rounded-3xl p-5 sm:p-6 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-orange-500/10 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold text-xs">
            🇮🇳
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Weather Across India
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Instant forecasts for major Indian metros, Andhra Pradesh, and regional destinations
            </p>
          </div>
        </div>

        {/* Region Category Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
          {INDIAN_REGIONS.map((region) => {
            const isSelected = selectedCategory === region.category;
            return (
              <button
                key={region.category}
                onClick={() => setSelectedCategory(region.category)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all shrink-0 ${
                  isSelected
                    ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950 shadow-sm'
                    : 'bg-white/50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200/60 dark:border-slate-700/60'
                }`}
              >
                {region.category}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Cities in Selected Region */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {activeRegion.cities.map((city) => {
          const isCurrentActive = activeCity.name.toLowerCase() === city.name.toLowerCase();
          const isSaved = isCitySaved(city.id);

          return (
            <div
              key={city.id}
              onClick={() => handleSelectCity(city)}
              className={`group relative p-3 rounded-2xl border text-left cursor-pointer transition-all duration-200 flex flex-col justify-between min-h-[96px] ${
                isCurrentActive
                  ? 'bg-sky-50 dark:bg-sky-950/40 border-sky-400 dark:border-sky-600 ring-2 ring-sky-500/20'
                  : 'bg-white/60 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 border-slate-200/70 dark:border-slate-700/70 hover:shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between gap-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                  {city.name}
                </span>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSaveCity(city);
                  }}
                  title={isSaved ? 'Favorited' : 'Save city'}
                  aria-label={`Favorite ${city.name}`}
                  className="text-slate-300 hover:text-rose-500 transition-colors shrink-0 p-0.5"
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${
                      isSaved ? 'text-rose-500 fill-current' : ''
                    }`}
                  />
                </button>
              </div>

              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {city.admin1}
                </p>
                <div className="mt-2 flex items-center justify-between text-[10px]">
                  <span
                    className={`font-semibold ${
                      isCurrentActive
                        ? 'text-sky-600 dark:text-sky-400'
                        : 'text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    {isCurrentActive ? 'Active Now' : 'Tap to view'}
                  </span>
                  <button
                    onClick={(e) => handleOpenDetail(city, e)}
                    title="View 7-day forecast"
                    className="text-slate-400 group-hover:text-sky-500 transition-colors"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
