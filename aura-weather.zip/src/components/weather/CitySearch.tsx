import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Search, X, MapPin, Loader2, Compass } from 'lucide-react';
import { fetchCitySuggestions } from '../../services/weatherApi';
import { CityLocation } from '../../types/weather';
import { useWeather } from '../../context/WeatherContext';

const POPULAR_CITIES: CityLocation[] = [
  { id: 1261481, name: 'New Delhi', latitude: 28.6139, longitude: 77.209, country: 'India', country_code: 'IN', admin1: 'Delhi' },
  { id: 1270583, name: 'Guntur', latitude: 16.3067, longitude: 80.4365, country: 'India', country_code: 'IN', admin1: 'Andhra Pradesh' },
  { id: 1275339, name: 'Mumbai', latitude: 19.076, longitude: 72.8777, country: 'India', country_code: 'IN', admin1: 'Maharashtra' },
  { id: 1277333, name: 'Bengaluru', latitude: 12.9716, longitude: 77.5946, country: 'India', country_code: 'IN', admin1: 'Karnataka' },
  { id: 1269843, name: 'Hyderabad', latitude: 17.385, longitude: 78.4867, country: 'India', country_code: 'IN', admin1: 'Telangana' },
  { id: 1264527, name: 'Chennai', latitude: 13.0827, longitude: 80.2707, country: 'India', country_code: 'IN', admin1: 'Tamil Nadu' },
  { id: 1275004, name: 'Kolkata', latitude: 22.5726, longitude: 88.3639, country: 'India', country_code: 'IN', admin1: 'West Bengal' },
  { id: 2643743, name: 'London', latitude: 51.5085, longitude: -0.1257, country: 'United Kingdom', country_code: 'GB', admin1: 'England' },
  { id: 5128581, name: 'New York', latitude: 40.7128, longitude: -74.006, country: 'United States', country_code: 'US', admin1: 'New York' },
];

export function CitySearch() {
  const { setActiveCity, activeCity } = useWeather();
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<CityLocation[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const [searchError, setSearchError] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Debounced search
  useEffect(() => {
    if (!query.trim() || query.trim().length < 2) {
      setSuggestions([]);
      setIsSearching(false);
      setSearchError(null);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      setSearchError(null);
      try {
        const results = await fetchCitySuggestions(query);
        setSuggestions(results);
        setIsOpen(true);
        setSelectedIndex(-1);
        if (results.length === 0) {
          setSearchError('No cities found. Try another spelling or country.');
        }
      } catch (err: any) {
        console.error('Search error:', err);
        setSearchError('Unable to search cities. Please check your internet connection.');
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectCity = useCallback(
    (city: CityLocation) => {
      setActiveCity(city);
      setQuery('');
      setSuggestions([]);
      setIsOpen(false);
      setSelectedIndex(-1);
    },
    [setActiveCity]
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen || suggestions.length === 0) {
      if (e.key === 'ArrowDown' && suggestions.length > 0) {
        setIsOpen(true);
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && selectedIndex < suggestions.length) {
        handleSelectCity(suggestions[selectedIndex]);
      } else if (suggestions.length > 0) {
        handleSelectCity(suggestions[0]);
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      inputRef.current?.blur();
    }
  };

  return (
    <div ref={containerRef} className="relative w-full z-30">
      <div className="relative flex items-center">
        <Search
          className="absolute left-4 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none"
          aria-hidden="true"
        />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => {
            if (suggestions.length > 0 || query.length >= 2) {
              setIsOpen(true);
            }
          }}
          onKeyDown={handleKeyDown}
          placeholder="Search city, state or country..."
          aria-label="Search city or location"
          role="combobox"
          aria-expanded={isOpen}
          aria-autocomplete="list"
          className="w-full pl-11 pr-11 py-3.5 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500 transition-all"
        />
        <div className="absolute right-3 flex items-center gap-1.5">
          {isSearching && (
            <Loader2 className="w-4 h-4 text-sky-500 animate-spin" aria-hidden="true" />
          )}
          {query && !isSearching && (
            <button
              onClick={() => {
                setQuery('');
                setSuggestions([]);
                setIsOpen(false);
                inputRef.current?.focus();
              }}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
              aria-label="Clear search input"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Suggestions Dropdown */}
      {isOpen && (suggestions.length > 0 || searchError) && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl shadow-slate-950/10 overflow-hidden z-40 max-h-80 overflow-y-auto">
          {searchError && (
            <div className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 text-center">
              {searchError}
            </div>
          )}

          {suggestions.map((item, index) => {
            const isSelected = index === selectedIndex;
            return (
              <button
                key={`${item.id}-${index}`}
                onClick={() => handleSelectCity(item)}
                onMouseEnter={() => setSelectedIndex(index)}
                className={`w-full px-4 py-3 flex items-center justify-between text-left transition-colors border-b border-slate-100 dark:border-slate-800/60 last:border-0 ${
                  isSelected
                    ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-950 dark:text-sky-100'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-sky-500 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {item.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {[item.admin1, item.country].filter(Boolean).join(', ')}
                    </p>
                  </div>
                </div>

                {item.country_code && (
                  <span className="text-[11px] font-mono font-medium text-slate-400 uppercase shrink-0 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                    {item.country_code}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Popular Quick Suggestions (Only when input is empty & unfocused) */}
      {!query && (
        <div className="mt-3 flex items-center gap-2 overflow-x-auto no-scrollbar py-1 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500 shrink-0 font-medium mr-1">
            <Compass className="w-3.5 h-3.5 text-sky-500" />
            <span>Popular:</span>
          </div>
          {POPULAR_CITIES.map((city) => {
            const isCurrent = activeCity.name === city.name;
            return (
              <button
                key={city.id}
                onClick={() => handleSelectCity(city)}
                className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors shrink-0 font-medium ${
                  isCurrent
                    ? 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20'
                    : 'bg-white/60 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200/60 dark:border-slate-700/60'
                }`}
              >
                {city.name}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
