import React from 'react';
import {
  Heart,
  Droplets,
  Wind,
  Gauge,
  Thermometer,
  ArrowUpRight,
  Calendar,
  Compass,
} from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';
import { getWeatherConditionInfo, WeatherIcon } from '../../utils/weatherCodes';

export function CurrentWeatherCard() {
  const {
    weather,
    activeCity,
    isCitySaved,
    toggleSaveCity,
    setActiveScreen,
    settings,
  } = useWeather();

  if (!weather) return null;

  const { current, daily } = weather;
  const isSaved = isCitySaved(activeCity.id);
  const condition = getWeatherConditionInfo(current.weatherCode);
  const todayDaily = daily[0];

  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°C' : '°F';
  const windUnitLabel = settings.windSpeedUnit === 'kmh' ? 'km/h' : 'mph';

  return (
    <div
      className={`relative overflow-hidden rounded-3xl border p-6 sm:p-8 backdrop-blur-xl transition-all duration-500 shadow-xl ${condition.cardLight} dark:${condition.cardDark}`}
    >
      {/* Decorative ambient gradient backdrop */}
      <div
        className={`absolute -top-24 -right-24 w-80 h-80 rounded-full blur-3xl opacity-30 pointer-events-none bg-gradient-to-br ${condition.gradientLight} dark:${condition.gradientDark}`}
      />

      {/* Top row: City metadata & Favorite Button */}
      <div className="relative z-10 flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              {activeCity.name}
            </h1>
            {activeCity.country_code && (
              <span className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400 bg-black/5 dark:bg-white/10 px-2 py-0.5 rounded">
                {activeCity.country_code}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
            <span>{[activeCity.admin1, activeCity.country].filter(Boolean).join(', ')}</span>
            {activeCity.timezone && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{activeCity.timezone.split('/')[1]?.replace('_', ' ') || activeCity.timezone}</span>
              </>
            )}
          </div>
        </div>

        {/* Save City Toggle Button */}
        <button
          onClick={() => toggleSaveCity(activeCity)}
          aria-label={isSaved ? `Remove ${activeCity.name} from saved cities` : `Save ${activeCity.name} to favorites`}
          title={isSaved ? 'Saved in favorites' : 'Save to favorites'}
          className={`p-3 rounded-2xl border transition-all active:scale-95 flex items-center gap-2 ${
            isSaved
              ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/20'
              : 'bg-white/60 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-slate-200/80 dark:border-slate-700/80 hover:text-rose-500 hover:border-rose-300'
          }`}
        >
          <Heart
            className={`w-5 h-5 transition-transform ${isSaved ? 'fill-current scale-110' : ''}`}
          />
          <span className="hidden sm:inline text-xs font-medium">
            {isSaved ? 'Saved' : 'Save city'}
          </span>
        </button>
      </div>

      {/* Center Hero: Temperature & Weather Icon */}
      <div className="relative z-10 my-6 sm:my-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
        <div className="flex items-baseline gap-2">
          <span className="text-6xl sm:text-7xl lg:text-8xl font-light tracking-tighter text-slate-900 dark:text-white tabular-nums">
            {current.temperature}
          </span>
          <span className="text-2xl sm:text-3xl font-medium text-slate-500 dark:text-slate-400">
            {tempSymbol}
          </span>
          {todayDaily && (
            <div className="ml-4 flex flex-col text-xs text-slate-500 dark:text-slate-400 font-mono">
              <span className="text-slate-700 dark:text-slate-200 font-semibold">
                H: {todayDaily.temperatureMax}{tempSymbol}
              </span>
              <span>
                L: {todayDaily.temperatureMin}{tempSymbol}
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-4">
          <div className="p-4 rounded-3xl bg-white/70 dark:bg-slate-800/80 shadow-md border border-slate-200/50 dark:border-slate-700/50">
            <WeatherIcon
              code={current.weatherCode}
              className="w-12 h-12 sm:w-16 sm:h-16"
            />
          </div>
          <div>
            <p className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-tight">
              {condition.label}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Feels like {current.apparentTemperature}{tempSymbol}
            </p>
          </div>
        </div>
      </div>

      {/* Atmospheric Metrics Strip */}
      <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-slate-200/60 dark:border-slate-800/60">
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/40 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-700/40">
          <Thermometer className="w-4 h-4 text-amber-500 shrink-0" />
          <div className="min-w-0">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
              Feels Like
            </p>
            <p className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
              {current.apparentTemperature}{tempSymbol}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/40 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-700/40">
          <Droplets className="w-4 h-4 text-sky-500 shrink-0" />
          <div className="min-w-0">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
              Humidity
            </p>
            <p className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
              {current.humidity}%
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/40 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-700/40">
          <Wind className="w-4 h-4 text-teal-500 shrink-0" />
          <div className="min-w-0">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
              Wind Speed
            </p>
            <p className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
              {current.windSpeed} {windUnitLabel}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/40 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-700/40">
          <Gauge className="w-4 h-4 text-indigo-500 shrink-0" />
          <div className="min-w-0">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
              Pressure
            </p>
            <p className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
              {current.pressure} hPa
            </p>
          </div>
        </div>
      </div>

      {/* "View Forecast" Button */}
      <div className="relative z-10 mt-6 flex justify-end">
        <button
          onClick={() => setActiveScreen('detail')}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-sky-500 dark:hover:bg-sky-400 dark:text-slate-950 font-semibold text-sm shadow-md transition-all active:scale-[0.98]"
        >
          <Calendar className="w-4 h-4" />
          <span>View 7-Day & Hourly Forecast</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
