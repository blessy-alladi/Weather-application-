import React from 'react';
import { CalendarDays, Droplets } from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';
import { getWeatherConditionInfo, WeatherIcon } from '../../utils/weatherCodes';

export function DailyForecastList() {
  const { weather, settings } = useWeather();

  if (!weather || !weather.daily || weather.daily.length === 0) return null;

  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°' : '°';

  // Calculate weekly global min and max for temperature range bar scaling
  const allMins = weather.daily.map((d) => d.temperatureMin);
  const allMaxs = weather.daily.map((d) => d.temperatureMax);
  const globalMin = Math.min(...allMins);
  const globalMax = Math.max(...allMaxs);
  const totalRange = Math.max(globalMax - globalMin, 1);

  return (
    <div className="rounded-3xl p-5 sm:p-6 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-sky-500" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            7-Day Forecast
          </h2>
        </div>
        <span className="text-xs text-slate-400">Weekly outlook</span>
      </div>

      <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
        {weather.daily.map((day, idx) => {
          const condition = getWeatherConditionInfo(day.weatherCode);
          const isToday = idx === 0;

          // Compute range bar positions
          const leftPercent = Math.max(
            0,
            Math.min(100, ((day.temperatureMin - globalMin) / totalRange) * 100)
          );
          const rightPercent = Math.max(
            0,
            Math.min(100, ((globalMax - day.temperatureMax) / totalRange) * 100)
          );

          return (
            <div
              key={day.date}
              className={`py-3.5 px-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/40 ${
                isToday ? 'bg-sky-50/40 dark:bg-sky-950/20' : ''
              }`}
            >
              {/* Day Name & Date */}
              <div className="flex items-center gap-3 w-32 shrink-0">
                <div>
                  <p className={`text-sm font-bold ${isToday ? 'text-sky-600 dark:text-sky-400' : 'text-slate-900 dark:text-white'}`}>
                    {day.dayName}
                  </p>
                  <p className="text-xs text-slate-400 dark:text-slate-500">
                    {day.formattedDate}
                  </p>
                </div>
              </div>

              {/* Weather Condition & Icon */}
              <div className="flex items-center gap-3 sm:w-44 shrink-0">
                <WeatherIcon code={day.weatherCode} className="w-6 h-6 shrink-0" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">
                  {condition.label}
                </span>
              </div>

              {/* Rain chance */}
              <div className="flex items-center gap-1.5 w-16 shrink-0 text-xs">
                {day.precipitationProbability > 0 ? (
                  <span className="flex items-center gap-1 text-sky-600 dark:text-sky-400 font-medium">
                    <Droplets className="w-3.5 h-3.5 shrink-0" />
                    <span>{day.precipitationProbability}%</span>
                  </span>
                ) : (
                  <span className="text-slate-300 dark:text-slate-600">—</span>
                )}
              </div>

              {/* Min, Range Bar, Max */}
              <div className="flex items-center gap-3 flex-1 min-w-[160px]">
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400 w-8 text-right tabular-nums">
                  {day.temperatureMin}{tempSymbol}
                </span>

                {/* Range bar */}
                <div className="relative flex-1 h-2 bg-slate-200/80 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="absolute top-0 bottom-0 rounded-full bg-gradient-to-r from-sky-400 via-amber-400 to-rose-400"
                    style={{
                      left: `${leftPercent}%`,
                      right: `${rightPercent}%`,
                    }}
                  />
                </div>

                <span className="text-xs font-mono font-bold text-slate-900 dark:text-white w-8 tabular-nums">
                  {day.temperatureMax}{tempSymbol}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
