import React from 'react';
import {
  CloudSun,
  RotateCw,
  MapPin,
  Sparkles,
} from 'lucide-react';
import { useWeather } from '../../context/WeatherContext';

export function Header() {
  const {
    activeCity,
    refreshWeather,
    isLoading,
    locateUser,
    isLocating,
    setActiveScreen,
  } = useWeather();

  return (
    <header className="sticky top-0 z-20 w-full backdrop-blur-md bg-white/70 dark:bg-slate-900/75 border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => setActiveScreen('home')}
          className="flex items-center gap-2.5 text-left focus:outline-none group shrink-0"
          aria-label="Aura Weather Home"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
            <CloudSun className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white leading-tight">
              Aura Weather
            </span>
          </div>
        </button>

        {/* Zone 2: Current Location Indicator (Clean single-line prose, zero-pill) */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 truncate max-w-sm">
          <MapPin className="w-3.5 h-3.5 text-sky-500 shrink-0" aria-hidden="true" />
          <span className="font-medium text-slate-700 dark:text-slate-200 truncate">
            {activeCity.name}
          </span>
          {activeCity.country && (
            <>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-600">·</span>
              <span className="truncate">{activeCity.country}</span>
              {(activeCity.country_code === 'IN' || activeCity.country === 'India') && (
                <span className="text-xs" title="India">🇮🇳</span>
              )}
            </>
          )}
        </div>

        {/* Zone 3: Actions (Refresh, Locate, Action buttons) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={locateUser}
            disabled={isLocating}
            title="Use current GPS location"
            aria-label="Use current location"
            className="p-2 sm:px-3 sm:py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <MapPin className={`w-4 h-4 text-sky-500 ${isLocating ? 'animate-bounce' : ''}`} />
            <span className="hidden md:inline">{isLocating ? 'Locating...' : 'Locate Me'}</span>
          </button>

          <button
            onClick={() => refreshWeather(true)}
            disabled={isLoading}
            title="Refresh current forecast"
            aria-label="Refresh current weather data"
            className="p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-50"
          >
            <RotateCw
              className={`w-4 h-4 ${isLoading ? 'animate-spin text-sky-500' : ''}`}
            />
          </button>
        </div>
      </div>
    </header>
  );
}
