import React from 'react';
import {
  Search,
  CalendarDays,
  Bookmark,
  Sliders,
} from 'lucide-react';
import { useWeather, ScreenType } from '../../context/WeatherContext';

interface NavItem {
  id: ScreenType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

const NAV_ITEMS: NavItem[] = [
  {
    id: 'home',
    label: 'Home',
    icon: Search,
    description: 'Current weather & search',
  },
  {
    id: 'detail',
    label: 'Forecast',
    icon: CalendarDays,
    description: '24-hour & 7-day outlook',
  },
  {
    id: 'saved',
    label: 'Saved',
    icon: Bookmark,
    description: 'Tracked favorite cities',
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Sliders,
    description: 'Units & appearance',
  },
];

export function Navigation() {
  const { activeScreen, setActiveScreen, savedCities } = useWeather();

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-slate-200/80 dark:border-slate-800/80 p-4 space-y-6 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
        <div className="space-y-1">
          <p className="px-3 text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Navigation
          </p>
          <nav className="space-y-1 mt-2">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveScreen(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-sky-500 text-white shadow-sm shadow-sky-500/20'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/70 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {item.id === 'saved' && savedCities.length > 0 && (
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-mono tabular-nums ${
                        isActive
                          ? 'bg-sky-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {savedCities.length}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick hint / tips widget */}
        <div className="mt-auto p-3.5 rounded-2xl bg-slate-100/60 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 text-xs text-slate-500 dark:text-slate-400 space-y-1">
          <p className="font-semibold text-slate-700 dark:text-slate-200">
            Open-Meteo Synced
          </p>
          <p className="text-[11px] leading-relaxed">
            Live free atmospheric models. Cached locally for 10 minutes to minimize data use.
          </p>
        </div>
      </aside>

      {/* Mobile Bottom Tab Bar (Ergonomic thumb zone, >=44px touch targets) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg border-t border-slate-200/80 dark:border-slate-800/80 pb-[env(safe-area-inset-bottom)]"
      >
        <div className="grid grid-cols-4 h-16 max-w-lg mx-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveScreen(item.id)}
                className={`relative flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
                  isActive
                    ? 'text-sky-500 dark:text-sky-400'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5 transition-transform active:scale-95" />
                  {item.id === 'saved' && savedCities.length > 0 && (
                    <span className="absolute -top-1 -right-2 w-4 h-4 bg-sky-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center font-mono">
                      {savedCities.length}
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-medium mt-1 tracking-tight">
                  {item.label}
                </span>
                {isActive && (
                  <span className="absolute bottom-1 w-6 h-0.5 bg-sky-500 dark:bg-sky-400 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
