import React from 'react';

export function WeatherCardSkeleton() {
  return (
    <div className="w-full rounded-3xl p-6 sm:p-8 bg-white/60 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800/80 animate-pulse space-y-6 backdrop-blur-md">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <div className="h-7 w-48 bg-slate-200 dark:bg-slate-800 rounded-lg" />
          <div className="h-4 w-32 bg-slate-200 dark:bg-slate-800 rounded-md" />
        </div>
        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800" />
      </div>

      <div className="flex items-center justify-between py-4">
        <div className="h-20 w-36 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
        <div className="w-20 h-20 rounded-2xl bg-slate-200 dark:bg-slate-800" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-200/60 dark:border-slate-800/60">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-16 rounded-xl bg-slate-200/70 dark:bg-slate-800/70" />
        ))}
      </div>
    </div>
  );
}

export function HourlyStripSkeleton() {
  return (
    <div className="flex gap-3 overflow-x-hidden py-2 animate-pulse">
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="w-20 h-28 shrink-0 rounded-2xl bg-white/60 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800/80"
        />
      ))}
    </div>
  );
}

export function DailyListSkeleton() {
  return (
    <div className="space-y-3 animate-pulse">
      {[...Array(7)].map((_, i) => (
        <div
          key={i}
          className="h-16 w-full rounded-2xl bg-white/60 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800/80"
        />
      ))}
    </div>
  );
}
