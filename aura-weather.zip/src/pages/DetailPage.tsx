import React from 'react';
import {
  ArrowLeft,
  Sunrise,
  Sunset,
  Share2,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { getWeatherConditionInfo, WeatherIcon } from '../utils/weatherCodes';
import { HourlyStrip } from '../components/weather/HourlyStrip';
import { DailyForecastList } from '../components/weather/DailyForecastList';
import { TemperatureChart } from '../components/weather/TemperatureChart';
import { WeatherMetricsGrid } from '../components/weather/WeatherMetricsGrid';
import {
  WeatherCardSkeleton,
  HourlyStripSkeleton,
  DailyListSkeleton,
} from '../components/common/SkeletonLoader';

export function DetailPage() {
  const {
    weather,
    activeCity,
    setActiveScreen,
    isLoading,
    settings,
    toggleSaveCity,
    isCitySaved,
  } = useWeather();

  if (isLoading && !weather) {
    return (
      <div className="space-y-6 max-w-4xl mx-auto pb-12">
        <div className="h-10 w-28 bg-slate-200 dark:bg-slate-800 rounded-xl animate-pulse" />
        <WeatherCardSkeleton />
        <HourlyStripSkeleton />
        <DailyListSkeleton />
      </div>
    );
  }

  if (!weather) {
    return (
      <div className="text-center py-16 space-y-4">
        <p className="text-slate-500">No forecast data available.</p>
        <button
          onClick={() => setActiveScreen('home')}
          className="px-4 py-2 rounded-xl bg-sky-500 text-white font-medium text-sm"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const { current, daily } = weather;
  const condition = getWeatherConditionInfo(current.weatherCode);
  const today = daily[0];
  const isSaved = isCitySaved(activeCity.id);
  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°C' : '°F';

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Top Header / Back Button bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveScreen('home')}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/60 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-sm font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-sm active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleSaveCity(activeCity)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
              isSaved
                ? 'bg-rose-500 text-white border-rose-500 shadow-sm'
                : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:text-rose-500'
            }`}
          >
            {isSaved ? 'Favorited' : 'Save City'}
          </button>
        </div>
      </div>

      {/* Screen Header Banner with City Name, Conditions, Sunrise & Sunset */}
      <div
        className={`rounded-3xl p-6 sm:p-8 border backdrop-blur-xl transition-all shadow-md ${condition.cardLight} dark:${condition.cardDark}`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">
              Detailed Forecast
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {activeCity.name}
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {[activeCity.admin1, activeCity.country].filter(Boolean).join(', ')}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-white/70 dark:bg-slate-800/80 shadow-sm border border-slate-200/60 dark:border-slate-700/60">
              <WeatherIcon code={current.weatherCode} className="w-10 h-10 sm:w-12 sm:h-12" />
            </div>
            <div>
              <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                {current.temperature}
                <span className="text-xl font-medium text-slate-400 ml-1">{tempSymbol}</span>
              </p>
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
                {condition.label}
              </p>
            </div>
          </div>
        </div>

        {/* Sunrise & Sunset quick row */}
        {today && (
          <div className="mt-6 pt-5 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-wrap items-center gap-6 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-2">
              <Sunrise className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Sunrise:</span>
              <span className="font-bold font-mono text-slate-900 dark:text-white">
                {today.sunrise}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Sunset className="w-4 h-4 text-orange-500 shrink-0" />
              <span>Sunset:</span>
              <span className="font-bold font-mono text-slate-900 dark:text-white">
                {today.sunset}
              </span>
            </div>
            <div className="ml-auto flex items-center gap-2 font-mono text-slate-500">
              <span>Day High: {today.temperatureMax}°</span>
              <span>·</span>
              <span>Low: {today.temperatureMin}°</span>
            </div>
          </div>
        )}
      </div>

      {/* 1. Next 24-Hours Hourly Strip */}
      <section className="space-y-2">
        <HourlyStrip />
      </section>

      {/* 2. Temperature Trend SVG Chart */}
      <section className="space-y-2">
        <TemperatureChart />
      </section>

      {/* 3. 7-Day Forecast Breakdown */}
      <section className="space-y-2">
        <DailyForecastList />
      </section>

      {/* 4. Atmospheric Metrics Grid */}
      <section className="space-y-2">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 px-1">
          Atmospheric Conditions
        </h2>
        <WeatherMetricsGrid />
      </section>
    </div>
  );
}
