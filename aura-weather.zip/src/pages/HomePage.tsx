import React from 'react';
import { AlertCircle, RotateCw, Sparkles, Compass } from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { CitySearch } from '../components/weather/CitySearch';
import { CurrentWeatherCard } from '../components/weather/CurrentWeatherCard';
import { HourlyStrip } from '../components/weather/HourlyStrip';
import { IndiaWeatherExplorer } from '../components/weather/IndiaWeatherExplorer';
import { WeatherCardSkeleton } from '../components/common/SkeletonLoader';

export function HomePage() {
  const { weather, isLoading, error, refreshWeather } = useWeather();

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Search Bar Section */}
      <section className="space-y-2">
        <CitySearch />
      </section>

      {/* Error state alert if any */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 text-sm">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={() => refreshWeather(true)}
            className="px-3 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-rose-900/60 dark:hover:bg-rose-900 text-rose-900 dark:text-rose-100 font-semibold text-xs transition-colors shrink-0 flex items-center gap-1.5"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Try Again</span>
          </button>
        </div>
      )}

      {/* Loading state skeleton */}
      {isLoading && !weather ? (
        <WeatherCardSkeleton />
      ) : (
        weather && (
          <>
            {/* Primary Current Weather Card */}
            <CurrentWeatherCard />

            {/* Next 24-Hour Sneak Peek on Home */}
            <div className="space-y-3">
              <HourlyStrip />
            </div>

            {/* India Weather Explorer */}
            <section className="space-y-3 pt-2">
              <IndiaWeatherExplorer />
            </section>
          </>
        )
      )}
    </div>
  );
}
