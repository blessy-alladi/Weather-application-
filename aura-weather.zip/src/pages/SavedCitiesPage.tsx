import React, { useState } from 'react';
import {
  Bookmark,
  Trash2,
  ArrowRight,
  Plus,
  Compass,
  MapPin,
  RefreshCw,
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { getWeatherConditionInfo, WeatherIcon } from '../utils/weatherCodes';
import { CityLocation } from '../types/weather';

const SUGGESTED_CITIES: CityLocation[] = [
  { id: 1261481, name: 'New Delhi', latitude: 28.6139, longitude: 77.209, country: 'India', country_code: 'IN', admin1: 'Delhi' },
  { id: 1270583, name: 'Guntur', latitude: 16.3067, longitude: 80.4365, country: 'India', country_code: 'IN', admin1: 'Andhra Pradesh' },
  { id: 1277333, name: 'Bengaluru', latitude: 12.9716, longitude: 77.5946, country: 'India', country_code: 'IN', admin1: 'Karnataka' },
  { id: 1275339, name: 'Mumbai', latitude: 19.076, longitude: 72.8777, country: 'India', country_code: 'IN', admin1: 'Maharashtra' },
  { id: 1269843, name: 'Hyderabad', latitude: 17.385, longitude: 78.4867, country: 'India', country_code: 'IN', admin1: 'Telangana' },
  { id: 1264527, name: 'Chennai', latitude: 13.0827, longitude: 80.2707, country: 'India', country_code: 'IN', admin1: 'Tamil Nadu' },
  { id: 1275004, name: 'Kolkata', latitude: 22.5726, longitude: 88.3639, country: 'India', country_code: 'IN', admin1: 'West Bengal' },
  { id: 2643743, name: 'London', latitude: 51.5085, longitude: -0.1257, country: 'United Kingdom', admin1: 'England' },
];

export function SavedCitiesPage() {
  const {
    savedCities,
    setActiveCity,
    setActiveScreen,
    removeSavedCity,
    toggleSaveCity,
    settings,
  } = useWeather();

  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);

  const handleCardClick = (city: CityLocation) => {
    setActiveCity(city);
    setActiveScreen('detail');
  };

  const tempSymbol = settings.temperatureUnit === 'celsius' ? '°C' : '°F';

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Saved Cities
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Tap any city card to view complete 7-day weather details
          </p>
        </div>
        <span className="text-xs font-mono font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
          {savedCities.length} Saved
        </span>
      </div>

      {/* Empty State */}
      {savedCities.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8 sm:p-12 text-center bg-white/40 dark:bg-slate-900/40 backdrop-blur-md space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-sky-50 dark:bg-sky-950/60 text-sky-500 flex items-center justify-center mx-auto">
            <Bookmark className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              No saved cities yet
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              Save your favorite destinations by tapping the heart icon on any weather card, or quick-add from popular choices below:
            </p>
          </div>

          <div className="pt-4 flex flex-wrap justify-center gap-2 max-w-lg mx-auto">
            {SUGGESTED_CITIES.map((city) => (
              <button
                key={city.id}
                onClick={() => {
                  toggleSaveCity(city);
                  setActiveCity(city);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-sky-500 text-xs font-medium text-slate-700 dark:text-slate-300 shadow-sm transition-all hover:scale-105"
              >
                <Plus className="w-3.5 h-3.5 text-sky-500" />
                <span>{city.name}</span>
                <span className="text-[10px] text-slate-400">({city.country})</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* Saved Cities Cards List */
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {savedCities.map((item) => {
            const { city, currentTemp, weatherCode, tempMax, tempMin } = item;
            const code = weatherCode ?? 0;
            const condition = getWeatherConditionInfo(code);

            return (
              <div
                key={city.id}
                className="group relative rounded-3xl border border-slate-200/80 dark:border-slate-800/80 bg-white/75 dark:bg-slate-900/75 p-5 sm:p-6 backdrop-blur-md shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <button
                      onClick={() => handleCardClick(city)}
                      className="text-left flex-1 min-w-0 focus:outline-none"
                    >
                      <h2 className="text-lg font-bold text-slate-900 dark:text-white truncate group-hover:text-sky-500 dark:group-hover:text-sky-400 transition-colors">
                        {city.name}
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {[city.admin1, city.country].filter(Boolean).join(', ')}
                      </p>
                    </button>

                    {/* Delete button with confirmation */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirmDeleteId === city.id) {
                          removeSavedCity(city.id);
                          setConfirmDeleteId(null);
                        } else {
                          setConfirmDeleteId(city.id);
                        }
                      }}
                      onBlur={() => setConfirmDeleteId(null)}
                      title={confirmDeleteId === city.id ? 'Tap again to confirm delete' : 'Delete saved city'}
                      aria-label={`Delete ${city.name} from saved cities`}
                      className={`p-2 rounded-xl transition-all ${
                        confirmDeleteId === city.id
                          ? 'bg-rose-500 text-white font-semibold text-xs px-2.5'
                          : 'text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                      }`}
                    >
                      {confirmDeleteId === city.id ? (
                        <span>Confirm?</span>
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {/* Temperature & Condition */}
                  <div
                    onClick={() => handleCardClick(city)}
                    className="cursor-pointer mt-4 flex items-center justify-between"
                  >
                    <div>
                      {currentTemp !== undefined ? (
                        <p className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums tracking-tight">
                          {currentTemp}
                          <span className="text-lg font-normal text-slate-400 ml-1">
                            {tempSymbol}
                          </span>
                        </p>
                      ) : (
                        <span className="text-xs text-slate-400">Tap to load</span>
                      )}
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5">
                        {condition.label}
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60">
                      <WeatherIcon code={code} className="w-8 h-8" />
                    </div>
                  </div>
                </div>

                {/* Footer with H/L & Tap to view arrow */}
                <div
                  onClick={() => handleCardClick(city)}
                  className="cursor-pointer mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs"
                >
                  <div className="text-slate-500 dark:text-slate-400 font-mono">
                    {tempMax !== undefined && tempMin !== undefined ? (
                      <span>
                        H: <strong className="text-slate-700 dark:text-slate-200">{tempMax}°</strong> · L: {tempMin}°
                      </span>
                    ) : (
                      <span>Open forecast</span>
                    )}
                  </div>
                  <span className="inline-flex items-center gap-1 text-sky-600 dark:text-sky-400 font-semibold group-hover:translate-x-1 transition-transform">
                    View Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
