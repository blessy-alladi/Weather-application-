import React, { useState } from 'react';
import {
  Sliders,
  Thermometer,
  Wind,
  SunMoon,
  Trash2,
  Check,
  CheckCircle,
  Database,
  Info,
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { clearWeatherCache } from '../services/weatherApi';
import { TemperatureUnit, WindSpeedUnit, ThemeMode } from '../types/weather';

export function SettingsPage() {
  const { settings, updateSettings, refreshWeather } = useWeather();
  const [clearedMessage, setClearedMessage] = useState(false);

  const handleClearCache = () => {
    clearWeatherCache();
    setClearedMessage(true);
    refreshWeather(true);
    setTimeout(() => setClearedMessage(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto pb-16">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Customize temperature, wind units, and visual appearance
        </p>
      </div>

      <div className="space-y-4">
        {/* 1. Temperature Unit */}
        <div className="rounded-3xl p-5 sm:p-6 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-500 flex items-center justify-center shrink-0">
              <Thermometer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Temperature Unit
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Choose Celsius or Fahrenheit for all temperature readouts
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => updateSettings({ temperatureUnit: 'celsius' })}
              className={`p-3.5 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                settings.temperatureUnit === 'celsius'
                  ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                  : 'bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <div className="text-left">
                <p>Celsius</p>
                <p className="text-xs opacity-80 font-normal">Metric (°C)</p>
              </div>
              {settings.temperatureUnit === 'celsius' && (
                <Check className="w-5 h-5" />
              )}
            </button>

            <button
              onClick={() => updateSettings({ temperatureUnit: 'fahrenheit' })}
              className={`p-3.5 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                settings.temperatureUnit === 'fahrenheit'
                  ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                  : 'bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <div className="text-left">
                <p>Fahrenheit</p>
                <p className="text-xs opacity-80 font-normal">Imperial (°F)</p>
              </div>
              {settings.temperatureUnit === 'fahrenheit' && (
                <Check className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* 2. Wind Speed Unit */}
        <div className="rounded-3xl p-5 sm:p-6 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-500 flex items-center justify-center shrink-0">
              <Wind className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Wind Speed Unit
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Unit used for wind velocity and gust measurements
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => updateSettings({ windSpeedUnit: 'kmh' })}
              className={`p-3.5 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                settings.windSpeedUnit === 'kmh'
                  ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                  : 'bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <div className="text-left">
                <p>Kilometers per hour</p>
                <p className="text-xs opacity-80 font-normal">km/h</p>
              </div>
              {settings.windSpeedUnit === 'kmh' && <Check className="w-5 h-5" />}
            </button>

            <button
              onClick={() => updateSettings({ windSpeedUnit: 'mph' })}
              className={`p-3.5 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                settings.windSpeedUnit === 'mph'
                  ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                  : 'bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <div className="text-left">
                <p>Miles per hour</p>
                <p className="text-xs opacity-80 font-normal">mph</p>
              </div>
              {settings.windSpeedUnit === 'mph' && <Check className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* 3. Theme Appearance */}
        <div className="rounded-3xl p-5 sm:p-6 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 flex items-center justify-center shrink-0">
              <SunMoon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Theme & Appearance
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Select visual mode or sync automatically with operating system
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-2">
            {(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => {
              const isSelected = settings.theme === mode;
              const labels: Record<ThemeMode, { title: string; desc: string }> = {
                light: { title: 'Light', desc: 'Day aesthetic' },
                dark: { title: 'Dark', desc: 'Night slate' },
                system: { title: 'System', desc: 'Auto match' },
              };
              return (
                <button
                  key={mode}
                  onClick={() => updateSettings({ theme: mode })}
                  className={`p-3 rounded-2xl border text-sm font-semibold text-center transition-all ${
                    isSelected
                      ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                      : 'bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <p className="capitalize">{labels[mode].title}</p>
                  <p className="text-[11px] opacity-80 font-normal">{labels[mode].desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Cache & Data Storage */}
        <div className="rounded-3xl p-5 sm:p-6 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Local Storage Cache
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Forecasts are cached for 10 minutes to reduce network consumption
                </p>
              </div>
            </div>

            <button
              onClick={handleClearCache}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-rose-400 hover:text-rose-500 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white/60 dark:bg-slate-800/60 transition-colors flex items-center gap-1.5 active:scale-95 shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Cache</span>
            </button>
          </div>

          {clearedMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <span>Cache cleared. Latest weather data refreshed!</span>
            </div>
          )}
        </div>

        {/* About Open-Meteo info */}
        <div className="p-4 rounded-2xl bg-slate-100/60 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/50 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
          <div className="space-y-0.5 leading-relaxed">
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              Open-Meteo Open Source Weather API
            </p>
            <p>
              Weather data is provided by national weather services (NOAA, ECMWF, DWD) through the Open-Meteo API under non-commercial and open data licenses.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
